import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeGardComponent } from './home-gard.component';

describe('HomeGardComponent', () => {
  let component: HomeGardComponent;
  let fixture: ComponentFixture<HomeGardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HomeGardComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HomeGardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
