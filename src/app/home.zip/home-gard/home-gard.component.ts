import { NgClass } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { RatingComponent } from '../rating/rating.component';

@Component({
  selector: 'app-home-gard',
  standalone: true,
  imports: [NgClass , RatingComponent],
  templateUrl: './home-gard.component.html',
  styleUrl: './home-gard.component.css'
})
export class HomeGardComponent {
@Input() productsList :any ;
@Output() sentToGard = new EventEmitter<string>();
rating: number = 0;
ratingChange: EventEmitter<number> = new EventEmitter<number>();


constructor(private router : Router){}

handleDeleteGame(id: string){
  console.log(id)
  this.sentToGard.emit(id)
}
handleNavigation(id : string){
  this.router.navigate(['Detalisproduct' , id])
}
currentRating: number = 0;

  updateRating(rating: number): void {
    this.currentRating = rating;
  }

}
